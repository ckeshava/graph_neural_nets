#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import tensorflow as tf
import etp as etp
import calculate_virtual_coordinates as cvc
import matplotlib.pyplot as plt

tf.enable_eager_execution()

from random import seed
from random import randint

import pickle
seed(23)

C = 5 # maximum number of anchors
H1 = 500 # size of hidden filters
H2 = 500 # size of hidden filters
F = 2 # Final dimension of coordinates
random_seed = 23
radius = 1 # extent of possible communication
MAX_NODES = 20
learning_rate = 0.2
epochs = 20
display_cost_period = 10
num_iter = 5

def plot_learning(cost_history):
    plt.plot(cost_history)
    plt.xlabel('Number of Graphs')
    plt.ylabel('Mean Squared Error')
    plt.title('Learning Curve')
    plt.show()





with open('max_1000_min_200_graphs_100_area_200.pickle', 'rb') as fp:
    data = pickle.load(fp)


# In[3]:


W_0 = tf.Variable(tf.truncated_normal(shape=(C, H1),
                                      mean=0.0,
                                      stddev=0.1,
                                      dtype=tf.float64,
                                      seed=random_seed), name='wt_1')
    
W_1 = tf.Variable(tf.truncated_normal(shape=(H1, H2),
                              mean=0.0,
                              stddev=0.1,
                              dtype=tf.float64,
                              seed=random_seed), name='wt_2')

W_2 = tf.Variable(tf.truncated_normal(shape=(H2, F),
                                mean=0.0,
                                stddev=0.1,
                                dtype=tf.float64,
                                seed=random_seed), name='wt_3')


# In[4]:



etp_history = []


for i in range(epochs):

    input_layer = data[i]['VC']
    physical_coordinates = data[i]['PC']
    adj = data[i]['Adj']
    A_caret = data[i]['Lap']
    
            
    
    print('Epoch: {}\tcalculated all inps'.format(i))
    

    out_1 = tf.matmul(tf.matmul(A_caret, input_layer), W_0)
    out_1 = tf.nn.relu(out_1)
    out_2 = tf.matmul(tf.matmul(A_caret, out_1), W_1)
    out_2 = tf.nn.relu(out_2)
    
    out_3 = tf.matmul(tf.matmul(A_caret, out_2), W_2)

    print('Graph-{}\tfinished forward prop'.format(i))
    
    curr_etp = etp.get_best_etp(out_3, data[i]['PC'])
    
    etp_history.append(curr_etp)

    print('Epoch: {}\t ETP-1(untrained neural network) : {}'.format(i, curr_etp))
writer.close()

    


# In[ ]:


with open('untrained_network_etp_history', 'wb') as fp:
    pickle.dump(etp_history, fp)


# In[5]:


tf.__version__


# In[ ]:




