#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pickle
import etp 
import tpm_from_vcs 
num_of_graphs = 100


# In[2]:


with open('data/connected_graph.pickle', 'rb') as fp:
    data = pickle.load(fp)


# In[3]:


etp_history = []
for i in range(num_of_graphs):
    
    input_layer = data[i]['VC']
    tpm_out = tpm_from_vcs.generate_tpm_from_vcs(input_layer)
    
    curr_etp = etp.get_best_etp(tpm_out, data[i]['PC'])
    
    etp_history.append(curr_etp)
    


# In[ ]:




