import matplotlib.pyplot as plt
import pickle

with open('tpm_cost_history', 'rb') as fp:
    tpm_data = pickle.load(fp)

plt.xlabel('Graph Ids')
plt.ylabel('ETP')
plt.plot(tpm_data)
plt.show()
