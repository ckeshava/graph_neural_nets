import pickle
import numpy as np
import queue
import calculate_virtual_coordinates as cvc

def dfs(node, visited, adj, num_of_nodes):

    visited[node] = 1

    # call dfs on it's neighbours
    for i in range(adj.shape[0]):
        if adj[node][i] == 1 and visited[i] == 0:
            visited, num_of_nodes = dfs(i, visited, adj, num_of_nodes + 1)

    return visited, num_of_nodes

def bfs(start_node, adj, nodes_list):
    q = queue.Queue(adj.shape[0])

    q.put(start_node)
    visited = np.zeros(adj.shape[0])
    visited[start_node] = 1

    while not q.empty():
        a = q.get()

        for i in range(adj.shape[0]):
            if not visited[i] and adj[a][i] == 1:
                q.put(i)
                visited[i] = 1
                nodes_list.add(i)

    return nodes_list

def is_connected(source, adj, visited):
    # print('is_connected is called')

    # visited, num_of_nodes = bfs(source, visited, adj, 1)
    visited, num_of_nodes = dfs(source, visited, adj, 1)

    return visited, num_of_nodes

def get_largest_component(adj):

    visited = np.zeros(adj.shape[0])
    size_of_largest_component = 0
    start_node_of_largest_component = -1

    while np.sum(visited) < adj.shape[0]:
        # find the smallest node that is not connected
        for i in range(adj.shape[0]):
            if not visited[i]:
                break

        visited, num_of_nodes = is_connected(i, adj, visited)

        if num_of_nodes > size_of_largest_component:
            size_of_largest_component = num_of_nodes
            start_node_of_largest_component = i

    return start_node_of_largest_component

def get_all_nodes(start_node, adj, nodes_list):
    for j in range(adj.shape[0]):
        if adj[start_node][j]:
            nodes_list.add(j)
            get_all_nodes(j, adj, nodes_list)

def test_is_connected():
    adj = np.zeros((10, 10)) + 1
    print('connectedness of mesh: {}'.format(get_largest_component(adj)))
    
    adj = np.eye(10)
    print('Connectedness of Idenity matrix: {}'.format(get_largest_component(adj)))

    print('testcase-3:')
    adj = np.zeros((5, 5))
    adj[0][1] = 1
    adj[1][0] = 1
    adj[1][3] = 1
    adj[3][1] = 1
    #adj[1][4] = 1
    #adj[4][1] = 1
    adj[0][2] = 1
    adj[2][0] = 1
    print('Connectedness of custom testcase matrix: {}'.format(get_largest_component(adj)))

def generate_largest_connected_graph():
    num_of_graphs = 100
    connected_data = {}

    with open('max_1000_min_200_graphs_100_area_200.pickle', 'rb') as fp:
        data = pickle.load(fp)

    for i in range(num_of_graphs):
        adj = data[i]['Adj']
        start_node = get_largest_component(adj)
        nodes = bfs(start_node, adj, set([start_node]))
        temp = {}
        temp['PC'] = data[i]['PC'][list(nodes), :]
        temp['VC'] = data[i]['VC'][list(nodes), :]
        
        temp['Adj'] = cvc.get_adj(temp['PC'])
        temp['Lap'] = cvc.normalize_adj(temp['Adj'] + np.eye(temp['Adj'].shape[0]))

        connected_data[i] = temp
        print('Completed Graph-{}'.format(i))

    with open('./connected_graph.pickle', 'wb') as fp:
        pickle.dump(connected_data, fp)

    return connected_data 

if __name__ == "__main__":
    generate_largest_connected_graph()


