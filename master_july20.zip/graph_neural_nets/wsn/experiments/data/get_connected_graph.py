# input is adj matrix
# output is a list of indices of nodes belonging to the largest component

size_of_largest_component

