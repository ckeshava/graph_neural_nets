import numpy as np
# import tensorflow as tf
# tf.enable_eager_execution()
# A and B are two (N by 2) matrices

# def func1(p, q, count_invs):
#         # print('DEBUG - func1: old count_invs = {}'.format(count_invs))
#         # print('I am in func1')
        
#         ans = tf.cond(p < q, lambda: add_1_func(), lambda: dummy_func())

#         # print('DEBUG - func1: NEW count_invs = {}'.format(ans))

#         return ans

# def func2(p, q, count_invs):
#         # print('DEBUG - func2    : old count_invs = {}'.format(count_invs))
#         # print('I am in func2')

#         ans = tf.cond(p > q, lambda: add_1_func(), lambda: dummy_func())
#         # print('DEBUG - func2: NEW count_invs = {}'.format(ans))

#         return ans



# def dummy_func():
#         # print('I am in dummy_func')
    
#         return 0

# def add_1_func():
#         return 1


def get_etp_without_rotation(A, B):


        # n = A.get_shape().as_list()[0]

        n = A.shape[0]
        # A = tf.cast(A, dtype=tf.float32)
        # B = tf.cast(B, dtype=tf.float32)


        count_invs = 0


        for i in range(0, n):
            print('Node: {}'.format(i))
            for j in range(0, n):
                
                    # print('DEBUG: Presently processing {} and {}'.format(i, j))

                    # # check for inversions along X-axis                        
                    # count_invs += tf.cond(A[i, 0] < A[j, 0], lambda: func1(B[j, 0], B[i, 0], count_invs), lambda: dummy_func())
                    # # print('DEBUG - MAIN: NEW count_invs = {}'.format(count_invs))

                    # count_invs += tf.cond(A[i, 0] > A[j, 0], lambda: func2(B[j, 0], B[i, 0], count_invs), lambda: dummy_func())
                    # # print('DEBUG - MAIN: NEW count_invs = {}'.format(count_invs))
                    
                    # # check for inversions along Y-axis
                    # count_invs += tf.cond(A[i, 1] < A[j, 1], lambda: func1(B[j, 1], B[i, 1], count_invs), lambda: dummy_func())
                    # # print('DEBUG - MAIN: NEW count_invs = {}'.format(count_invs))

                    # count_invs += tf.cond(A[i, 1] > A[j, 1], lambda: func2(B[j, 1], B[i, 1], count_invs), lambda: dummy_func())
                    # # print('DEBUG - MAIN: NEW count_invs = {}'.format(count_invs))

                    if(A[i, 0] < A[j, 0] and B[j, 0] < B[i, 0]):
                        count_invs += 1

                    if(A[i, 0] > A[j, 0] and B[j, 0] > B[i, 0]):
                        count_invs += 1

                    if(A[i, 1] < A[j, 1] and B[j, 1] < B[i, 1]):
                        count_invs += 1

                    if(A[i, 1] > A[j, 1] and B[j, 1] > B[i, 1]):
                        count_invs += 1

        count_invs/=(n * (n - 1))
        count_invs *= 100
        return count_invs



# A is true value
# B is predicted value
def get_best_etp(A, B):

        x = 0
        final_etp = get_etp_without_rotation(A, B)
        for x in range(0, 360, 50):
                print('Rotation: {}'.format(x))
                rot_matrix = np.array([[np.cos(np.radians(x)), -np.sin(np.radians(x))], [np.sin(np.radians(x)), np.cos(np.radians(x))]])
                # rot_matrix = tf.convert_to_tensor(rot_matrix, dtype=tf.float32)
                temp = get_etp_without_rotation(A, np.matmul(B, rot_matrix))

        return final_etp