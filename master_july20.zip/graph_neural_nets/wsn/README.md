The number of nodes is chosen randomly between (10, MAX_NODES), where MAX_NODES = 1000

Below models have been trained on y different graphs. Naming convention: 
h_x_g_y.png: x hidden layers, trained on y graphs.
